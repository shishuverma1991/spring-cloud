insert into user(name,password,username) values ('adminshishu','{noop}password','shishu verma');
insert into user(name,password,username) values ('usershishu','{noop}password','shishu verma');
insert into role(role) values ('ADMIN');
insert into role(role) values ('USER');