package com.aricent.poc.message.microservice.helper;

public enum REPOSITORYRESPONSECODE {

    SUCCESS("DONE"),
    FAILURE("FAILURE");
    
    private String responseCode;

    private REPOSITORYRESPONSECODE(String responseCode) {
        this.responseCode=responseCode;
    }

    public String getResponseCode() {
        return responseCode;
    }

}
