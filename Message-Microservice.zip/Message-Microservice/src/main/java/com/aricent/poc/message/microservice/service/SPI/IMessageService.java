package com.aricent.poc.message.microservice.service.SPI;

import com.aricent.poc.message.microservice.DTOs.MessageModel;
import com.aricent.poc.message.microservice.helper.REPOSITORYRESPONSECODE;
import com.aricent.poc.mscommon.CustomException;

public interface IMessageService {
  
  public REPOSITORYRESPONSECODE saveMessage(MessageModel message) throws CustomException;
}
