package com.aricent.poc.message.microservice.repository;

import org.springframework.data.repository.CrudRepository;
import com.aricent.poc.message.microservice.entity.Role;
import com.aricent.poc.message.microservice.entity.User;
import java.util.List;

public interface IRoleRepository  extends CrudRepository<Role, Long>{

	List<Role> findByUser(User user);

    List<Role> findByUser_id(Long userid);
}
