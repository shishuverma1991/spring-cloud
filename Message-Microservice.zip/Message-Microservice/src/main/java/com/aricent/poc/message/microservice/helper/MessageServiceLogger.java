package com.aricent.poc.message.microservice.helper;

import org.springframework.stereotype.Component;
import com.aricent.poc.mscommon.CustomLogger;

@Component
public class MessageServiceLogger  extends CustomLogger
{
  
  public MessageServiceLogger() {
   super();
  }

}
