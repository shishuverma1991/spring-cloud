package com.aricent.poc.message.microservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class MessageMicroserviceApplication {
	private final static Logger logger = LoggerFactory.getLogger(MessageMicroserviceApplication.class);
	
	public static void main(String[] args) {
		logger.info("Spring Boot is starting Message Application!");
		SpringApplication.run(MessageMicroserviceApplication.class, args);
		logger.info("Spring Boot has started Message Application succesfully!");
	}


}
