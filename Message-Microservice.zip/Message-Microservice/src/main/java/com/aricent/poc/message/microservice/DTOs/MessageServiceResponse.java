package com.aricent.poc.message.microservice.DTOs;

import org.springframework.hateoas.ResourceSupport;
import com.aricent.poc.message.microservice.helper.RESPONSECODE;

public class MessageServiceResponse extends ResourceSupport {
  
  private String responseMessage;
  private long responseStatusCode;
  
  
  public MessageServiceResponse() {
    super();
  }


  public MessageServiceResponse(String responseMessage, long responseStatusCode) {
    super();
    this.responseMessage = responseMessage;
    this.responseStatusCode = responseStatusCode;
  }


  public MessageServiceResponse(String responseMessage, RESPONSECODE responsecode) {
    super();
    this.responseMessage = responseMessage;
    this.responseStatusCode = responsecode.getResponseCode();
  }


  public String getResponseMessage() {
    return responseMessage;
  }


  public void setResponseMessage(String responseMessage) {
    this.responseMessage = responseMessage;
  }


  public long getResponseStatusCode() {
    return responseStatusCode;
  }


  public void setResponseStatusCode(long responseStatusCode) {
    this.responseStatusCode = responseStatusCode;
  }

}
