package com.aricent.poc.message.microservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.aricent.poc.message.microservice.entity.Message;

public interface IMessageRepository extends JpaRepository<Message,Long>{

}
