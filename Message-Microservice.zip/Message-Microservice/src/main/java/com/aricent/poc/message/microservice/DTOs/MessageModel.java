package com.aricent.poc.message.microservice.DTOs;

import java.util.Date;
import javax.validation.constraints.NotBlank;
import org.springframework.stereotype.Component;

@Component
public class MessageModel {

  @NotBlank
  private String message;
 
  private String userName;
  
  private Date creationTimesatmp;

  public MessageModel(String message, String userName, Date creationTimesatmp) {
    super();
    this.message = message;
    this.userName = userName;
    this.creationTimesatmp = creationTimesatmp;
  }

  public MessageModel() {
    super();
    // TODO Auto-generated constructor stub
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public Date getCreationTimesatmp() {
    return creationTimesatmp;
  }

  public void setCreationTimesatmp(Date creationTimesatmp) {
    this.creationTimesatmp = creationTimesatmp;
  }
  
  
  
  
  
  

}
