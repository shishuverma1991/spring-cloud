package com.aricent.poc.message.microservice.service;

public class CustomAuthManagerUserDetails {
	
	
	private Long id;
	private String password;
	private String username;
	private boolean enabled=true;
	
	
	public CustomAuthManagerUserDetails(Long id,String password, String username, boolean enabled) {
		super();
		this.setId(id);
		this.password = password;
		this.username = username;
		this.enabled = enabled;
	}
	public String getPassword() {
		return password;
	}
	public String getUsername() {
		return username;
	}
	public boolean isEnabled() {
		return enabled;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	public  boolean validate(CustomAuthManagerUserDetails u, String username,String passowrd) {
		boolean flag=false;
		if(username.equals(u.getUsername()) && passowrd.equals(u.getPassword())) {
			flag= true;
		}
		
		return flag;
	}
	
}
