package com.aricent.poc.message.microservice.helper;

public enum ERRORCODE {
	
	ERROR_SERVICE("Error_001"),
	Error_Exception("Error_100");
	
	private String errorCode;

	private ERRORCODE(String errorCode) {
		this.errorCode=errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	
	
	
}
