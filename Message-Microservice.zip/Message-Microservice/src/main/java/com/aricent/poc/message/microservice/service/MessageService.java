package com.aricent.poc.message.microservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.aricent.poc.message.microservice.DTOs.MessageModel;
import com.aricent.poc.message.microservice.entity.Message;
import com.aricent.poc.message.microservice.helper.REPOSITORYRESPONSECODE;
import com.aricent.poc.message.microservice.repository.IMessageRepository;
import com.aricent.poc.message.microservice.service.SPI.IMessageService;
import com.aricent.poc.mscommon.CustomException;

@Service
public class MessageService implements IMessageService{
  
  @Autowired
  private IMessageRepository messageRepository;

  @Override
  public REPOSITORYRESPONSECODE saveMessage(MessageModel message) throws CustomException {
    Message messageEntity =new Message(message.getMessage(),message.getUserName(),message.getCreationTimesatmp());
    
    Message savedMessage = messageRepository.save(messageEntity);
    if(savedMessage.getId()<0) {
      return REPOSITORYRESPONSECODE.FAILURE;
    }else {
       return REPOSITORYRESPONSECODE.SUCCESS;
    }
  }

}
