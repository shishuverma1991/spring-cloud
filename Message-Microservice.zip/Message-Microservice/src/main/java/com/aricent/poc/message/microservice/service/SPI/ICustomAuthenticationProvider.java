package com.aricent.poc.message.microservice.service.SPI;

import org.springframework.security.authentication.AuthenticationProvider;

public interface ICustomAuthenticationProvider extends AuthenticationProvider {

}
