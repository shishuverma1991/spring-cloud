package com.aricent.poc.message.microservice.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;
import com.aricent.poc.message.microservice.entity.Role;
import com.aricent.poc.message.microservice.entity.User;
import com.aricent.poc.message.microservice.repository.IRoleRepository;
import com.aricent.poc.message.microservice.repository.IUserRepository;
import com.aricent.poc.message.microservice.service.SPI.ICustomAuthenticationProvider;


@Service
public class CustomAuthenticationProvider implements ICustomAuthenticationProvider {
	
	
	@Autowired
	private IUserRepository userRepository;
	
	@Autowired
	private IRoleRepository roleRepository;
	
	
	List<CustomAuthManagerUserDetails> users = new ArrayList<CustomAuthManagerUserDetails>();
	 
	@PostConstruct
	void init() {
		Iterable<User> repouser = userRepository.findAll();
		Iterator<User> iterator = repouser.iterator();
		while(iterator.hasNext()) {
			User ruser = iterator.next();
			users.add(new CustomAuthManagerUserDetails(ruser.getId(),ruser.getPassword(),ruser.getUsername(),true));
		}
	}
	
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		String name = authentication.getName();
		String password = authentication.getCredentials().toString();
 
		Optional<CustomAuthManagerUserDetails> optionalUser = users.stream().filter(u ->u.validate(u,name,password)).findFirst();
 
		if (!optionalUser.isPresent()) {
			throw new BadCredentialsException("Authentication failed for user = " + name);
		}
		// find out the exited users
		List<GrantedAuthority> grantedAuthorities =preapareUserDetailsImpl(optionalUser.get().getId());
		
		UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(name, password,grantedAuthorities);
 
		return auth;
	}

	

	@Override
	public boolean supports(Class<?> authentication) {
		// TODO Auto-generated method stub
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}

	
	private List<GrantedAuthority> preapareUserDetailsImpl(Long userid){
		List<Role> roles =roleRepository.findByUser_id(userid); 
		List<GrantedAuthority> grantedAuthorities=new ArrayList<GrantedAuthority>();
		roles.stream().forEach(role->grantedAuthorities.add(new SimpleGrantedAuthority(role.getRole())));
		return grantedAuthorities;
	}
}
