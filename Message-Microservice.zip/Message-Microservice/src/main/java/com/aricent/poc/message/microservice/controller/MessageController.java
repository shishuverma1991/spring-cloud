package com.aricent.poc.message.microservice.controller;

import java.security.Principal;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.aricent.poc.message.microservice.DTOs.MessageModel;
import com.aricent.poc.message.microservice.DTOs.MessageServiceResponse;
import com.aricent.poc.message.microservice.helper.REPOSITORYRESPONSECODE;
import com.aricent.poc.message.microservice.service.SPI.IMessageService;
import com.aricent.poc.mscommon.CustomException;
import com.aricent.poc.mscommon.spi.IcustomLogger;

@RestController
@RequestMapping("/Message-Service")
public class MessageController {

  @Autowired
  private IcustomLogger messageLogger;

  @Autowired
  private IMessageService messageService;
  
  

  @GetMapping(value = "/PostMessage/{message}" ,produces=MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<MessageServiceResponse> saveMessage(
      @PathVariable(required = true, name = "message") String message,Principal principal) throws CustomException {
    messageLogger.controllerEntryLog("Saving message.", message, Level.INFO, MessageController.class);
    MessageModel messageModel = ControllerUtility.prepareMessageModel(message, principal.getName());
    ResponseEntity<MessageServiceResponse> reponseEntity = null;
    REPOSITORYRESPONSECODE saveMessage = messageService.saveMessage(messageModel);
    if (saveMessage.getResponseCode().equals("FAILURE")) {
      throw new CustomException("Error in Message Service");
    } else {
      reponseEntity = ControllerUtility.formResponse(saveMessage.getResponseCode());
    }
    
    
    messageLogger.controllerExitLog("Message Saved successfully.", null, Level.INFO, MessageController.class);
    return reponseEntity;
  }

  /*
   * private void readAllMessage() { // TODO Auto-generated method stub
   * 
   * }
   * 
   * 
   * private void readMessageById() { // TODO Auto-generated method stub
   * 
   * }
   */

}
