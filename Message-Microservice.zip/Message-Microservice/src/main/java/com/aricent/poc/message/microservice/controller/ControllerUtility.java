package com.aricent.poc.message.microservice.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;
import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import com.aricent.poc.message.microservice.DTOs.MessageModel;
import com.aricent.poc.message.microservice.DTOs.MessageServiceResponse;
import com.aricent.poc.message.microservice.helper.RESPONSECODE;
import com.aricent.poc.mscommon.CustomException;

final  class ControllerUtility {
  
  
  public static MessageModel prepareMessageModel(String message,String username) {
    Date date = new Date();
    MessageModel messageModel=new MessageModel(message,username,date);
    return messageModel;
  }

  public static ResponseEntity<MessageServiceResponse> formResponse(final String reponseMessage) throws CustomException {
    MessageServiceResponse messageReponse = new MessageServiceResponse(reponseMessage, RESPONSECODE.SAVEDSUCCESSFULLY);
    List<Link> links = prepareLinkList();
    if (links.size() > 0) {
      messageReponse.add(links);
    }
    ResponseEntity<MessageServiceResponse> reponseEntity = new ResponseEntity<MessageServiceResponse>(messageReponse,
        HttpStatus.CREATED);
    return reponseEntity;
  }

  public static List<Link> prepareLinkList() throws CustomException {
    List<Link> linkList = new ArrayList<Link>();
    linkList.add(linkTo(methodOn(MessageController.class).saveMessage("message",null)).withSelfRel());
    // linkList.add(linkTo(methodOn(AppController.class).getInstanceLimits("minimum")).withRel("Limit
    // maximum"));
    // linkList.add(linkTo(methodOn(AppController.class).performOperation("SUM")).withRel("Perform
    // Direct SUM"));
    // linkList.add(linkTo(methodOn(AppController.class).performOperation("SUB")).withRel("Perform
    // Direct SUB"));
    // linkList.add(linkTo(methodOn(AppController.class).feignperformOperation("SUM")).withRel("Perform
    // Feign SUM"));
    // linkList.add(linkTo(methodOn(AppController.class).feignperformOperation("SUB")).withRel("Perform
    // Feign SUB"));
    return linkList;

  }
  
  
  public static Authentication getAuthentication() {
    Authentication Authentication = SecurityContextHolder.getContext().getAuthentication();
    return Authentication;
  }
}
