package com.aricent.poc.message.microservice.service.SPI;


import org.springframework.security.core.userdetails.UserDetailsService;

public interface ICustomUserDetailsService extends UserDetailsService{

}
