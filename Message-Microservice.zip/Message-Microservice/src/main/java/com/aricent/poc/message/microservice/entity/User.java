package com.aricent.poc.message.microservice.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class User implements Serializable {

  private static final long serialVersionUID = 1L;
  
  @Id
  @GeneratedValue(strategy=GenerationType.AUTO)
  @Column
  private long id;
  
  @Column
  private String name;
  
  @Column
  private String username;
  
  @Column
  private String password;
  
  @OneToMany(cascade=CascadeType.ALL,orphanRemoval=true,mappedBy="user")
  private List<Role> roles=new ArrayList<Role>();

  public User() {
    super();
  }

  public User(Long id) {
    this.id = id; // TODO Auto-generated constructor stub
  }

  public long getId() {
    return id;
  }

  public void setId(long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getPassword() {
    return password;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public List<Role> getRoles() {
    return roles;
  }

  public void setRoles(List<Role> roles) {
    this.roles = roles;
  }

  
  
  
}
