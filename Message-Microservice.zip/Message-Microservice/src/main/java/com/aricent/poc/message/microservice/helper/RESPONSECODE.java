package com.aricent.poc.message.microservice.helper;

public enum RESPONSECODE {

    SAVEDSUCCESSFULLY(200l),
    RETRIEVEDSUCCESSFULLY(201l),
    SAVEFAILED(401l);;
    
    private long responseCode;

    private RESPONSECODE(long responseCode) {
        this.responseCode=responseCode;
    }

    public long getResponseCode() {
        return responseCode;
    }

}
