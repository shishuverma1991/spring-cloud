package com.aricent.poc.message.microservice.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import com.aricent.poc.message.microservice.entity.Role;
import com.aricent.poc.message.microservice.entity.User;
import com.aricent.poc.message.microservice.repository.IRoleRepository;
import com.aricent.poc.message.microservice.repository.IUserRepository;
import com.aricent.poc.message.microservice.service.SPI.ICustomUserDetailsService;





@Service
public class CustomUserDetailsService implements ICustomUserDetailsService {
	
	@Autowired
	private IUserRepository userRepository;
	
	@Autowired
	private IRoleRepository roleRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		return preapareUserDetailsImpl(username);
	}
	
	
	
	private CustomUserDetailsImpl preapareUserDetailsImpl(String username){
		User repouser = userRepository.findByUsername(username).get(0);
		List<Role> roles =roleRepository.findByUser(repouser); 
		List<GrantedAuthority> grantedAuthorities=new ArrayList<GrantedAuthority>();
		roles.stream().forEach(role->grantedAuthorities.add(new SimpleGrantedAuthority(role.getRole())));
		CustomUserDetailsImpl userDetailsImpl=new CustomUserDetailsImpl(grantedAuthorities, repouser.getPassword(),repouser.getUsername(), true, true, true, true);
		return userDetailsImpl;
	}
	
	
	
}
