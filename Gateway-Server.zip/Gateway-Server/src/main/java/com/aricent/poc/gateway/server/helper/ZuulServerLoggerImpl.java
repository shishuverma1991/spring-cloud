package com.aricent.poc.gateway.server.helper;

import org.springframework.stereotype.Component;
import com.aricent.poc.mscommon.CustomLogger;

@Component
public class ZuulServerLoggerImpl extends CustomLogger {

    public ZuulServerLoggerImpl() {
        super();
    }
}

