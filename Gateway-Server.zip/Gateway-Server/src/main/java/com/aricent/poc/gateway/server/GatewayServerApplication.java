package com.aricent.poc.gateway.server;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;

@SpringBootApplication
@EnableEurekaClient
@EnableZuulProxy
public class GatewayServerApplication {

  private final static Logger logger = LoggerFactory.getLogger(GatewayServerApplication.class);

  public static void main(String[] args) {
    logger.info("Spring Boot is starting Config Server Application!");
    SpringApplication.run(GatewayServerApplication.class, args);
    logger.info("Spring Boot has started Config Server Application succesfully!");
  }
}
