package com.example.aricent.eurekaServer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;


@EnableEurekaServer
@SpringBootApplication
public class EurekaServerApplication {
	private final static Logger logger = LoggerFactory.getLogger(EurekaServerApplication.class);
	public static void main(String[] args) {
		logger.info("Spring Boot is starting Eureka Server Application!");
		SpringApplication.run(EurekaServerApplication.class, args);
		logger.info("Spring Boot has started Eureka Server Application succesfully!");
	}
}
