package com.aricent.poc.mscommon;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.event.Level;

import com.aricent.poc.mscommon.spi.IcustomLogger;

public abstract class CustomLogger implements IcustomLogger {
    private Logger logger = null;
    
    
    public void controllerEntryLog(String msg, Object value, Level level,Class<?> clazz) {
        this.logger = LoggerFactory.getLogger(clazz);
        String controllerName=clazz.getSimpleName();
        String message=msg!=null?msg:"No Message.";
        switch (level) {
        
        case INFO:
            logger.info("Entering Controller--"+controllerName+ " Message: "+message+" with value {}",  (value!=null?value:"Not defined."));
            break;
        case ERROR:
            logger.error("Entering Controller--"+controllerName+ " with error: "+message);
            break;
        case WARN:
            logger.warn("Entering Controller--"+controllerName+ " with warning: "+message);
            break;
        case DEBUG:
            logger.debug("Debugging Controller--"+controllerName+ " Message: "+message+" with value {}", (value!=null?value:"Not defined."));
            break;
        case TRACE:
            logger.trace("Tracing Controller--"+controllerName+ " Message: "+message+" with value {}",  (value!=null?value:"Not defined."));
            break;
        default:
            logger.info("Entering Controller--"+controllerName+ " Message: "+message+" with value {}", (value!=null?value:"Not defined."));
            break;
        }
    }
    public void controllerExitLog(String msg, Object value, Level level,Class<?> clazz) {
        this.logger = LoggerFactory.getLogger(clazz);
        String controllerName=clazz.getSimpleName();
        String message=msg!=null?msg:"No Message.";
        switch (level) {
        
        case INFO:
            logger.info("Exiting Controller--"+controllerName+ " Message: "+message+" with value {}",  (value!=null?value:"Not defined."));
            break;
        case ERROR:
            logger.error("Exiting Controller--"+controllerName+ " with error: "+message);
            break;
        case WARN:
            logger.warn("Exiting Controller--"+controllerName+ " with warning: "+message);
            break;
        case DEBUG:
            logger.debug("Debugging Controller--"+controllerName+ " Message: "+message+" with value {}", (value!=null?value:"Not defined."));
            break;
        case TRACE:
            logger.trace("Tracing Controller--"+controllerName+ " Message: "+message+" with value {}",  (value!=null?value:"Not defined."));
            break;
        default:
            logger.info("Exiting Controller--"+controllerName+ " Message: "+message+" with value {}", (value!=null?value:"Not defined."));
            break;
        }
    }
    public void serviceEntryLog(String msg, Object value, Level level,Class<?> clazz) {
        this.logger = LoggerFactory.getLogger(clazz);
        String controllerName=clazz.getSimpleName();
        String message=msg!=null?msg:"No Message.";
        switch (level) {
        
        case INFO:
            logger.info("Entering Service--"+controllerName+ " Message: "+message+" with value {}",  (value!=null?value:"Not defined."));
            break;
        case ERROR:
            logger.error("Entering Service--"+controllerName+ " with error: "+message);
            break;
        case WARN:
            logger.warn("Entering Service--"+controllerName+ " with warning: "+message);
            break;
        case DEBUG:
            logger.debug("Debugging Service--"+controllerName+ " Message: "+message+" with value {}", (value!=null?value:"Not defined."));
            break;
        case TRACE:
            logger.trace("Tracing Service--"+controllerName+ " Message: "+message+" with value {}",  (value!=null?value:"Not defined."));
            break;
        default:
            logger.info("Entering Service--"+controllerName+ " Message: "+message+" with value {}", (value!=null?value:"Not defined."));
            break;
        }
    }
    public void serviceExitLog(String msg, Object value, Level level,Class<?> clazz) {
        this.logger = LoggerFactory.getLogger(clazz);
        String controllerName=clazz.getSimpleName();
        String message=msg!=null?msg:"No Message.";
        switch (level) {
        
        case INFO:
            logger.info("Exiting Service--"+controllerName+ " Message: "+message+" with value {}",  (value!=null?value:"Not defined."));
            break;
        case ERROR:
            logger.error("Exiting Service--"+controllerName+ " with error: "+message);
            break;
        case WARN:
            logger.warn("Exiting Service--"+controllerName+ " with warning: "+message);
            break;
        case DEBUG:
            logger.debug("Debugging Service--"+controllerName+ " Message: "+message+" with value {}", (value!=null?value:"Not defined."));
            break;
        case TRACE:
            logger.trace("Tracing Service--"+controllerName+ " Message: "+message+" with value {}",  (value!=null?value:"Not defined."));
            break;
        default:
            logger.info("Exiting Service--"+controllerName+ " Message: "+message+" with value {}", (value!=null?value:"Not defined."));
            break;
        }
    }
    
    public void respositoryEntryLog(String msg, Object value, Level level,Class<?> clazz) {
        this.logger = LoggerFactory.getLogger(clazz);
        String controllerName=clazz.getSimpleName();
        String message=msg!=null?msg:"No Message.";
        switch (level) {
        
        case INFO:
            logger.info("Entering Repository--"+controllerName+ " Message: "+message+" with value {}",  (value!=null?value:"Not defined."));
            break;
        case ERROR:
            logger.error("Entering Repository--"+controllerName+ " with error: "+message);
            break;
        case WARN:
            logger.warn("Entering Repository--"+controllerName+ " with warning: "+message);
            break;
        case DEBUG:
            logger.debug("Debugging Repository--"+controllerName+ " Message: "+message+" with value {}", (value!=null?value:"Not defined."));
            break;
        case TRACE:
            logger.trace("Tracing Repository--"+controllerName+ " Message: "+message+" with value {}",  (value!=null?value:"Not defined."));
            break;
        default:
            logger.info("Entering Repository--"+controllerName+ " Message: "+message+" with value {}", (value!=null?value:"Not defined."));
            break;
        }
    }
    public void respositoryExitLog(String msg, Object value, Level level,Class<?> clazz) {
        this.logger = LoggerFactory.getLogger(clazz);
        String controllerName=clazz.getSimpleName();
        String message=msg!=null?msg:"No Message.";
        switch (level) {
        
        case INFO:
            logger.info("Exiting Repository--"+controllerName+ " Message: "+message+" with value {}",  (value!=null?value:"Not defined."));
            break;
        case ERROR:
            logger.error("Exiting Repository--"+controllerName+ " with error: "+message);
            break;
        case WARN:
            logger.warn("Exiting Repository--"+controllerName+ " with warning: "+message);
            break;
        case DEBUG:
            logger.debug("Exiting Repository--"+controllerName+ " Message: "+message+" with value {}", (value!=null?value:"Not defined."));
            break;
        case TRACE:
            logger.trace("Exiting Repository--"+controllerName+ " Message: "+message+" with value {}",  (value!=null?value:"Not defined."));
            break;
        default:
            logger.info("Exiting Repository--"+controllerName+ " Message: "+message+" with value {}", (value!=null?value:"Not defined."));
            break;
        }
    }
}
