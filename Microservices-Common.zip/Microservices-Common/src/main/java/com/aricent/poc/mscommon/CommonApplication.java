package com.aricent.poc.mscommon;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommonApplication {
    
    public static void main(String[] args) {
        
    }
}
