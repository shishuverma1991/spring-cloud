package com.aricent.poc.mscommon;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CommonExceptionStructure {
    private final String dateFormat = "dd-MM-yyyy HH:mm:ss.SS";
    private String timeStamp;
    private String errorCode;
    private String errorDesc;

    public CommonExceptionStructure(Date timeStamp, String errorCode, String errorDesc) {
        super();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(dateFormat);
        if (timeStamp != null) {
            this.timeStamp = simpleDateFormat.format(timeStamp);
        } else {
            this.timeStamp = simpleDateFormat.format(new Date());
        }
        this.errorCode = errorCode;
        this.errorDesc = errorDesc;
    }

    public CommonExceptionStructure(String errorCode, String errorDesc) {
        this(new Date(), errorCode, errorDesc);
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorDesc() {
        return errorDesc;
    }

    public void setErrorDesc(String errorDesc) {
        this.errorDesc = errorDesc;
    }

}
