package com.aricent.poc.mscommon.spi;

import org.slf4j.event.Level;

public interface IcustomLogger {
    
    public void controllerEntryLog(String msg, Object value, Level level,Class<?> clazz);
    public void controllerExitLog(String msg, Object value, Level level,Class<?> clazz);
    public void serviceEntryLog(String msg, Object value, Level level,Class<?> clazz);
    public void serviceExitLog(String msg, Object value, Level level,Class<?> clazz);
    public void respositoryEntryLog(String msg, Object value, Level level,Class<?> clazz);
    public void respositoryExitLog(String msg, Object value, Level level,Class<?> clazz);
}
