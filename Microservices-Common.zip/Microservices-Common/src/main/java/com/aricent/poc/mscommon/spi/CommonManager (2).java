package com.aricent.poc.mscommon.spi;

public interface CommonManager {
    
    public String getConfiguration(String key);
}
