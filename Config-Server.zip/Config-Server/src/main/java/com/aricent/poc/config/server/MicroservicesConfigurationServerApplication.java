package com.aricent.poc.config.server;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

@SpringBootApplication
@EnableConfigServer
public class MicroservicesConfigurationServerApplication {

  private final static Logger logger = LoggerFactory.getLogger(MicroservicesConfigurationServerApplication.class);

  public static void main(String[] args) {
    logger.info("Spring Boot is starting Config Server Application!");
    SpringApplication.run(MicroservicesConfigurationServerApplication.class, args);
    logger.info("Spring Boot has started Config Server Application succesfully!");
  }
}
