package com.aricent.poc.calculation.microservice.service;

import java.math.BigDecimal;

import javax.validation.Valid;

import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.aricent.poc.calculation.microservice.controller.CalculationController;
import com.aricent.poc.calculation.microservice.entity.InputData;
import com.aricent.poc.calculation.microservice.helper.OPERATION;
import com.aricent.poc.calculation.microservice.helper.RepoResponse;
import com.aricent.poc.calculation.microservice.model.InputModel;
import com.aricent.poc.calculation.microservice.model.ResponseModel;
import com.aricent.poc.calculation.microservice.repository.InputDataRepo;
import com.aricent.poc.mscommon.CustomException;
import com.aricent.poc.mscommon.spi.IcustomLogger;

@Service
public class CalculationService {
    @Autowired
    private InputDataRepo inputdataRepo;
    @Autowired
    private IcustomLogger logger;
    @Autowired
    private Environment environment;
    
    public ResponseModel findSumAndSave(BigDecimal firstValue, BigDecimal secondValue) throws CustomException {
        logger.serviceEntryLog(" In Method: findSumAndSave ", null, Level.INFO, CalculationService.class);
        
        BigDecimal result = firstValue.add(secondValue);
        String profile = environment.getProperty("server.port") + "----"
                + environment.getProperty("spring.cloud.config.profile");
        InputData inputData = new InputData(firstValue, secondValue, result, OPERATION.SUM.getName(), profile);
        InputData save = inputdataRepo.save(inputData);
        Long id = save.getId();
        logger.serviceExitLog(" Method: findSumAndSave ", id, Level.INFO, CalculationService.class);
        if (id > 0) {
            ResponseModel reponseModel = new ResponseModel(save, RepoResponse.SUCCESS);
            return reponseModel;
        } else {
            throw new CustomException("Sorry Service Is down");
        }
    }
    
    public ResponseModel findSubAndSave(BigDecimal firstValue, BigDecimal secondValue) throws CustomException {
        logger.serviceEntryLog(" In Method: findSubAndSave ", null, Level.INFO, CalculationService.class);
        BigDecimal result = firstValue.subtract(secondValue);
        String profile = environment.getProperty("server.port") + "----"
                + environment.getProperty("spring.cloud.config.profile");
        InputData inputData = new InputData(firstValue, secondValue, result, OPERATION.SUB.getName(), profile);
        InputData save = inputdataRepo.save(inputData);
        Long id = save.getId();
        logger.serviceExitLog(" Method: findSubAndSave ", id, Level.INFO, CalculationService.class);
        if (id > 0) {
            ResponseModel reponseModel = new ResponseModel(save, RepoResponse.SUCCESS);
            return reponseModel;
        } else {
            throw new CustomException("Sorry Service Is down");
        }
    }
    
    
    
    
    
    public void validate(@Valid InputModel inputModel){
        
       System.out.println(inputModel);
        
        
    }
}
