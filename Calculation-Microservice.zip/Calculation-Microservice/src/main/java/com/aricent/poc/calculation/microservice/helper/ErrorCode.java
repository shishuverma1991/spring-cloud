package com.aricent.poc.calculation.microservice.helper;

public enum ErrorCode {
	
	Key_Null("Error_001"),
	Error_Exception("Error_100");
	
	private String errorCode;

	private ErrorCode(String errorCode) {
		this.errorCode=errorCode;
	}

	public String getErrorCode() {
		return errorCode;
	}

	
	
	
}
