package com.aricent.poc.calculation.microservice.helper;

public enum OPERATION {
    
    SUM("sum"),
    SUB("sub");
    
    private String name;

    private OPERATION(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
    
}
