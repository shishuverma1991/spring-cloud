package com.aricent.poc.calculation.microservice.helper;

public enum RepoResponse {
    
    SUCCESS("DONE"),
    FAILURE("ERROR");
    
    private String response;

    private RepoResponse(String response) {
        this.response = response;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }
    
    
}
