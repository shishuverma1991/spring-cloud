package com.aricent.poc.calculation.microservice.entity;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class InputData {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    
    
    private BigDecimal firstValue;
    private BigDecimal secondValue;
    private BigDecimal resultValue;
    private String operation;
    private String profile;
    
    public InputData() {
        // TODO Auto-generated constructor stub
    }
    
    public InputData(BigDecimal firstValue, BigDecimal secondValue, BigDecimal resultValue, String operation,String profile) {
        super();
        this.firstValue = firstValue;
        this.secondValue = secondValue;
        this.resultValue = resultValue;
        this.operation = operation;
        this.profile=profile;
    }
    
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public BigDecimal getFirstValue() {
        return firstValue;
    }
    
    public void setFirstValue(BigDecimal firstValue) {
        this.firstValue = firstValue;
    }
    
    public BigDecimal getSecondValue() {
        return secondValue;
    }
    
    public void setSecondValue(BigDecimal secondValue) {
        this.secondValue = secondValue;
    }
    
    public BigDecimal getResultValue() {
        return resultValue;
    }
    
    public void setResultValue(BigDecimal resultValue) {
        this.resultValue = resultValue;
    }
    
    public String getOperation() {
        return operation;
    }
    
    public void setOperation(String operation) {
        this.operation = operation;
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        this.profile = profile;
    }
    
    
}
