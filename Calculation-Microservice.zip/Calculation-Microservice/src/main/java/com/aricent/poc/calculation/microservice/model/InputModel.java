package com.aricent.poc.calculation.microservice.model;
import java.math.BigDecimal;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;

import org.springframework.stereotype.Component;

@Component
public class InputModel {
    

    @NotBlank
    @Digits(fraction=3,integer=4,message="Only Float value allowed <xxxx.xxx>")
    private BigDecimal firstValue;
    
    @NotBlank
    @Digits(fraction=3,integer=4,message="Only Float value allowed <xxxx.xxx>")
    private BigDecimal secondValue;
    
    public InputModel() {
        // TODO Auto-generated constructor stub
    }
    
   
    public BigDecimal getFirstValue() {
        return firstValue;
    }
    public void setFirstValue(BigDecimal firstValue) {
        this.firstValue = firstValue;
    }
    public BigDecimal getSecondValue() {
        return secondValue;
    }
    public void setSecondValue(BigDecimal secondValue) {
        this.secondValue = secondValue;
    }
    
    
}
