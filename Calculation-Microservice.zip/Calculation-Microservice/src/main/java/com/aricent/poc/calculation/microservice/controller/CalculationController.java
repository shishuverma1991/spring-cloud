package com.aricent.poc.calculation.microservice.controller;

import javax.validation.Valid;

import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.aricent.poc.calculation.microservice.model.InputModel;
import com.aricent.poc.calculation.microservice.model.ResponseModel;
import com.aricent.poc.calculation.microservice.service.CalculationService;
import com.aricent.poc.mscommon.CustomException;
import com.aricent.poc.mscommon.spi.IcustomLogger;

@RestController
public class CalculationController {
    @Autowired
    private IcustomLogger logger;
    @Autowired
    private CalculationService calculationService;
    
    @PostMapping(value = "/SUM", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseModel> getSum(@Valid @RequestBody InputModel inputModel) throws CustomException {
        logger.controllerEntryLog(" In Method: getSum ", null, Level.INFO, CalculationController.class);
       
        ResponseModel findSumAndSave = calculationService.findSumAndSave(inputModel.getFirstValue(),
                inputModel.getSecondValue());
        logger.controllerExitLog(" Method: getSum ", findSumAndSave, Level.INFO, CalculationController.class);
        return new ResponseEntity<ResponseModel>(findSumAndSave, HttpStatus.ACCEPTED);
    }
    
    @PostMapping(value = "/SUB", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ResponseModel> getSub(@RequestBody InputModel inputModel) throws CustomException {
        logger.controllerEntryLog(" In Method: getSum ", null, Level.INFO, CalculationController.class);
        ResponseModel findSubAndSave = calculationService.findSubAndSave(inputModel.getFirstValue(),
                inputModel.getSecondValue());
        logger.controllerExitLog(" Method: getSum ", findSubAndSave, Level.INFO, CalculationController.class);
        return new ResponseEntity<ResponseModel>(findSubAndSave, HttpStatus.ACCEPTED);
    }
}
