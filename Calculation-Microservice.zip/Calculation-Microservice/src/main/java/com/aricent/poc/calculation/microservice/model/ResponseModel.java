package com.aricent.poc.calculation.microservice.model;

import java.math.BigDecimal;

import org.springframework.http.ResponseEntity;

import com.aricent.poc.calculation.microservice.entity.InputData;
import com.aricent.poc.calculation.microservice.helper.RepoResponse;

public class ResponseModel {
    private String responseMessage;
    private BigDecimal result;
    private String Operation;
    
    
    

    public ResponseModel(String responseMessage, BigDecimal result, String Operation) {
        super();
        this.responseMessage = responseMessage;
        this.result = result;
        this.Operation = Operation;
    }

    public ResponseModel(InputData save, RepoResponse success) {
        super();
        this.responseMessage = success.getResponse();
        this.result = save.getResultValue();
        this.Operation = save.getOperation();
    }

    public String getResponseMessage() {
        return responseMessage;
    }
    
    public BigDecimal getResult() {
        return result;
    }

    public void setResult(BigDecimal result) {
        this.result = result;
    }

    public String getOperation() {
        return Operation;
    }

    public void setOperation(String Operation) {
        this.Operation = Operation;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }
}
