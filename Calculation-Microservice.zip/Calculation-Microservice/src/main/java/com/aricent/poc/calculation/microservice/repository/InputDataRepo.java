package com.aricent.poc.calculation.microservice.repository;


import org.springframework.data.repository.CrudRepository;


import com.aricent.poc.calculation.microservice.entity.InputData;

public interface InputDataRepo extends CrudRepository<InputData, Long>{
    
    
}
