package com.aricent.poc.IntakeMicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntakeMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntakeMicroserviceApplication.class, args);
	}
}
